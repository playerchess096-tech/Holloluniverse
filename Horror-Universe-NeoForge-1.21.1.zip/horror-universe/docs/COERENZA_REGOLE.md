# Coerenza delle regole del prompt (contraddizioni trovate e soluzioni adottate)

Il prompt chiede di segnalare le contraddizioni e di proporre una soluzione senza modificare in silenzio le regole.
Ecco cosa ho trovato e come l'ho gestito. Tutto è modificabile in `Config` o nel codice indicato.

| # | Problema | Soluzione adottata |
|---|----------|--------------------|
| 1 | La soglia "attacco superiore a 7" esclude la spada di diamante (attacco 7), ma il prompt dice che l'Arcimago muore con una spada di diamante. | Soglie per entità: generale 7 (quindi spada di netherite = 8 vale), Custode lv4 = 7, Arcimago = 6,5 (il diamante vale). Opzioni `attackThreshold`, `custode4Threshold`, `archmageThreshold`. |
| 2 | Corrotto lv1-2 è "non direttamente attaccabile", ma la tabella 9.4 dà colpi per l'arma lv3/lv6 contro di lui. | Vulnerabilità **specifica**: i colpi normali non valgono; solo le armi di Entity 404 lo feriscono (lv3: 2 colpi, lv6: 1 colpo). |
| 3 | Custode lv5 "non si sconfigge con armi normali": le armi lv3/lv6 di Entity 404 sono "normali"? | Sì: nemmeno loro lo feriscono. Servono 10 colpi con Perle Rituali nella finestra di ancoraggio, poi si elimina l'Enderman Corrotto dal Rituale. |
| 4 | Custode lv5 si attiva "senza permesso dal lv3" ma anche "dopo il lv4 per convincerti". | Un solo innesco coerente per entrambi i casi: Altare Rituale + Occhio di Ender + Enderman vicino, con Custode lv3 completato. |
| 5 | Numeri di colpi non specificati: Entity 404 lv5, lv6, lv4, fase post-distruzione, Uomo Magico, Steve, Osservatore. | Proposte (modificabili nel codice): lv5 = 8/4 colpi (arma lv3/lv6), lv6 = 12/6, lv4 = 3 colpi con arma lv3 o lv6 nelle finestre in cui si inginocchia. Mago/Steve usano la soglia normale; la fase post-distruzione è immune e termina dopo ~10 minuti. |
| 6 | "Morte permanente" vs "non cancellare dati". | Morte narrativa: spettatore reversibile; torna da sola dopo `permadeathAutoRecoverMinutes`, con il Totem di Recupero su un Altare, o con `/horror recover`. |
| 7 | Entity 404 lv7 "distrugge il mondo" vs "non cancellare il salvataggio". | Se scade il timer: flag "mondo devastato", tempesta permanente e forma post-distruzione. `/horror restore` annulla tutto. Nessun blocco viene perso. |
| 8 | Frutto dell'Eden "protegge dagli effetti negativi previsti" senza elenco. | Protegge da: Elettrizzato, Corruzione, Sigillo Runico, Instabilità Gravitazionale, Presenza Interiore. Non annulla danno diretto, Piaga o Anima Assorbita. |
| 9 | L'Osservatore non deve diventare "un altro boss". | Ha tre prove (Lente dell'Osservatore): buio, tracce nei luoghi visitati, sequenza di sigilli. Non si combatte. |
| 10 | Clone di Entity 404 alleato "per lo scontro finale" ma le alleanze sono per giocatore. | Il flag di alleanza è del mondo (`clone_allied`) e persiste. |
