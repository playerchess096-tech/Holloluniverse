# Controllo di coerenza: id usati nel codice Java vs manifest, chiavi di traduzione, JSON validi.
import re, json, glob, os, sys
R = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
man = json.load(open(R + '/src/main/resources/horror_content.json', encoding='utf-8'))
ids = dict(item={i['id'] for i in man['items']} | {b['id'] for b in man['blocks']}, block={b['id'] for b in man['blocks']}, type={m['id'] for m in man['mobs']} | {b['id'] for b in man['bosses']},
           fx={e['id'] for e in man['effects']}, sound=set(man['sounds']))
bad = 0
src = ''
for f in glob.glob(R + '/src/main/java/**/*.java', recursive=True): src += open(f, encoding='utf-8').read() + '\n'
for kind, rx in (('item', r'Reg\.item\("([a-z0-9_]+)"\)'), ('block', r'Reg\.block\("([a-z0-9_]+)"\)'), ('type', r'Reg\.(?:type|mob)\("([a-z0-9_]+)"\)'), ('fx', r'Reg\.fx\("([a-z0-9_]+)"\)'), ('sound', r'Reg\.sound\("([a-z0-9_]+)"\)')):
    for m in set(re.findall(rx, src)):
        if m not in ids[kind]: print('ID MANCANTE', kind, m); bad += 1
for m in set(re.findall(r'(?:soundTo|Fx\.sound)\([^;]*?"([a-z_0-9\.]+)"', src)):
    if m not in ids['sound']: print('SUONO MANCANTE', m); bad += 1
lang = json.load(open(R + '/src/main/resources/assets/horror_universe/lang/it_it.json', encoding='utf-8'))
for k in set(re.findall(r'"((?:msg|say)\.[a-z0-9_]+)"', src)):
    if 'horror_universe.' + k not in lang: print('CHIAVE LANG MANCANTE', k); bad += 1
for m in re.findall(r'Fx\.say\([^,]+,\s*(?:Ent\.([A-Z0-9]+)|ent),\s*(\d+)\)', src):
    pass
for f in glob.glob(R + '/src/main/resources/**/*.json', recursive=True):
    try: json.load(open(f, encoding='utf-8'))
    except Exception as e: print('JSON NON VALIDO', f, e); bad += 1
# i file di texture/modello promessi dal manifest esistono?
A = R + '/src/main/resources/assets/horror_universe'
for i in man['items']:
    if i['kind'] != 'egg' and not os.path.exists(A + '/textures/item/%s.png' % i['id']): print('TEXTURE ITEM MANCANTE', i['id']); bad += 1
    if not os.path.exists(A + '/models/item/%s.json' % i['id']): print('MODELLO ITEM MANCANTE', i['id']); bad += 1
for m in man['mobs'] + man['bosses']:
    if not os.path.exists(A + '/textures/entity/%s.png' % m['id']): print('TEXTURE ENTITA MANCANTE', m['id']); bad += 1
for s in man['sounds']:
    fn = s.replace('.', '_')
    if not (os.path.exists(A + '/sounds/%s.ogg' % fn) or os.path.exists(A + '/sounds/%s_1.ogg' % fn)): print('OGG MANCANTE', s); bad += 1
print('LINT: problemi =', bad); sys.exit(1 if bad else 0)
