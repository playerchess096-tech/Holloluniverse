import struct, gzip
class N:
    def __init__(s, t, v): s.t = t; s.v = v
def I(v): return N(3, v)
def S(v): return N(8, v)
def Bt(v): return N(1, v)
def Lg(v): return N(4, v)
def Dn(v): return N(6, v)
def Li(items): return N(9, items)
def C(d): return N(10, d)
def enc(n):
    t, v = n.t, n.v
    if t == 1: return struct.pack('>b', v)
    if t == 3: return struct.pack('>i', v)
    if t == 4: return struct.pack('>q', v)
    if t == 6: return struct.pack('>d', v)
    if t == 8: b = v.encode('utf-8'); return struct.pack('>H', len(b)) + b
    if t == 9:
        et = v[0].t if v else 0
        return struct.pack('>b', et) + struct.pack('>i', len(v)) + b''.join(enc(x) for x in v)
    if t == 10:
        out = b''
        for k, x in v.items():
            kb = k.encode(); out += struct.pack('>b', x.t) + struct.pack('>H', len(kb)) + kb + enc(x)
        return out + b'\x00'
def write(path, root):
    import os; os.makedirs(os.path.dirname(path), exist_ok=True)
    with gzip.open(path, 'wb') as f: f.write(b'\x0a' + struct.pack('>H', 0) + enc(C(root)))
class St:
    def __init__(s, sx, sy, sz): s.size = (sx, sy, sz); s.b = {}; s.ents = []
    def set(s, x, y, z, name, props=None, nbt=None):
        if 0 <= x < s.size[0] and 0 <= y < s.size[1] and 0 <= z < s.size[2]: s.b[(x, y, z)] = (name, tuple(sorted((props or {}).items())), nbt)
    def fill(s, x1, y1, z1, x2, y2, z2, name, props=None):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for z in range(min(z1, z2), max(z1, z2) + 1): s.set(x, y, z, name, props)
    def shell(s, x1, y1, z1, x2, y2, z2, name):
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                for z in range(z1, z2 + 1):
                    if x in (x1, x2) or y in (y1, y2) or z in (z1, z2): s.set(x, y, z, name)
    def ent(s, eid, x, y, z): s.ents.append((eid, x, y, z))
    def chest(s, x, y, z, loot, facing='south'): s.set(x, y, z, 'minecraft:chest', {'facing': facing, 'type': 'single', 'waterlogged': 'false'}, {'id': 'minecraft:chest', 'LootTable': 'horror_universe:chests/' + loot})
    def save(s, path):
        pal = {}; blocks = []
        for (x, y, z), (name, props, nbt) in s.b.items():
            k = (name, props)
            if k not in pal: pal[k] = len(pal)
            e = {'pos': Li([I(x), I(y), I(z)]), 'state': I(pal[k])}
            if nbt: e['nbt'] = C({kk: (S(vv) if isinstance(vv, str) else I(vv)) for kk, vv in nbt.items()})
            blocks.append(C(e))
        plist = []
        for (name, props), i in sorted(pal.items(), key=lambda kv: kv[1]):
            d = {'Name': S(name)}
            if props: d['Properties'] = C({k: S(v) for k, v in props})
            plist.append(C(d))
        ents = [C({'pos': Li([Dn(x + 0.5), Dn(y), Dn(z + 0.5)]), 'blockPos': Li([I(int(x)), I(int(y)), I(int(z))]), 'nbt': C({'id': S('horror_universe:' + e), 'PersistenceRequired': Bt(1)})}) for (e, x, y, z) in s.ents]
        write(path, {'DataVersion': I(3955), 'size': Li([I(v) for v in s.size]), 'palette': Li(plist), 'blocks': Li(blocks), 'entities': Li(ents)})
