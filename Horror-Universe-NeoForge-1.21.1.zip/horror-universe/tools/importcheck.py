import re, glob, os, sys, collections
R = os.path.abspath(os.path.join(os.path.dirname(__file__), '..')); files = glob.glob(R + '/src/main/java/**/*.java', recursive=True)
def strip(src):
    src = re.sub(r'/\*.*?\*/', ' ', src, flags=re.S); src = re.sub(r'//[^\n]*', ' ', src); src = re.sub(r'"(?:\\.|[^"\\])*"', '""', src); return src
srcs = {f: strip(open(f, encoding='utf-8').read()) for f in files}
mine = {}   # nome classe -> fqcn (classi mie)
for f, s in srcs.items():
    pkg = re.search(r'package ([\w.]+);', s).group(1)
    for m in re.finditer(r'\b(?:class|interface|enum|record)\s+([A-Z]\w*)', s): mine.setdefault(m.group(1), pkg + '.' + m.group(1))
glob_map = collections.defaultdict(set)   # nome -> {package} da import espliciti in tutto il progetto
for s in srcs.values():
    for m in re.finditer(r'import\s+(?:static\s+)?([\w.]+)\.([A-Z]\w*)(?:\.\w+)?;', s): glob_map[m.group(2)].add(m.group(1))
JAVA_LANG = set('String Math Object Integer Double Float Long Boolean Byte Short Character Exception RuntimeException Runnable Override SuppressWarnings Iterable Comparable Number Enum Record Thread System StringBuilder Class Void Deprecated FunctionalInterface Throwable Error CharSequence IllegalArgumentException IllegalStateException'.split())
# classi vanilla/NeoForge che uso SOLO tramite import con asterisco: package noto (dalla mia conoscenza dell'API 1.21.1)
KNOWN = {'Vec3':'net.minecraft.world.phys','AABB':'net.minecraft.world.phys','Mob':'net.minecraft.world.entity','Entity':'net.minecraft.world.entity','EntityType':'net.minecraft.world.entity','LivingEntity':'net.minecraft.world.entity','EquipmentSlot':'net.minecraft.world.entity','MobSpawnType':'net.minecraft.world.entity','MobCategory':'net.minecraft.world.entity','AreaEffectCloud':'net.minecraft.world.entity','SpawnPlacements':'net.minecraft.world.entity','SpawnPlacementTypes':'net.minecraft.world.entity','Monster':'net.minecraft.world.entity.monster','MobEffects':'net.minecraft.world.effect','MobEffectInstance':'net.minecraft.world.effect','MobEffect':'net.minecraft.world.effect','MobEffectCategory':'net.minecraft.world.effect','Items':'net.minecraft.world.item','ItemStack':'net.minecraft.world.item','Item':'net.minecraft.world.item','Blocks':'net.minecraft.world.level.block','Block':'net.minecraft.world.level.block','Level':'net.minecraft.world.level','Mth':'net.minecraft.util','RandomSource':'net.minecraft.util','BlockPos':'net.minecraft.core','Component':'net.minecraft.network.chat','ServerLevel':'net.minecraft.server.level','ServerPlayer':'net.minecraft.server.level','ServerBossEvent':'net.minecraft.server.level','DamageSource':'net.minecraft.world.damagesource','DamageTypes':'net.minecraft.world.damagesource','ParticleTypes':'net.minecraft.core.particles','ParticleOptions':'net.minecraft.core.particles','DustParticleOptions':'net.minecraft.core.particles','BossEvent':'net.minecraft.world','InteractionHand':'net.minecraft.world','InteractionResult':'net.minecraft.world','InteractionResultHolder':'net.minecraft.world','Container':'net.minecraft.world','Player':'net.minecraft.world.entity.player','Attributes':'net.minecraft.world.entity.ai.attributes','Goal':'net.minecraft.world.entity.ai.goal','FloatGoal':'net.minecraft.world.entity.ai.goal','MeleeAttackGoal':'net.minecraft.world.entity.ai.goal','LookAtPlayerGoal':'net.minecraft.world.entity.ai.goal','PickaxeItem':'net.minecraft.world.item','SwordItem':'net.minecraft.world.item','ClipContext':'net.minecraft.world.level','HitResult':'net.minecraft.world.phys','BlockHitResult':'net.minecraft.world.phys','Heightmap':'net.minecraft.world.level.levelgen','ChatFormatting':'net.minecraft','CompoundTag':'net.minecraft.nbt','ListTag':'net.minecraft.nbt','LongTag':'net.minecraft.nbt','Tag':'net.minecraft.nbt','TickTask':'net.minecraft.server','ClickEvent':'net.minecraft.network.chat','ExplosionInteraction':'net.minecraft.world.level.Level'}
bad = 0
for f, s in srcs.items():
    pkg = re.search(r'package ([\w.]+);', s).group(1); explicit = {m.group(2): m.group(1) for m in re.finditer(r'import\s+(?:static\s+)?([\w.]+)\.([A-Z]\w*)(?:\.\w+)?;', s)}
    wild = set(re.findall(r'import\s+([\w.]+)\.\*;', s)) | {pkg}
    local = set(re.findall(r'\b(?:class|interface|enum|record)\s+([A-Z]\w*)', s)); tparams = set(re.findall(r'<\s*([A-Z]\w*)\s+extends', s)) | set(re.findall(r'<\s*([A-Z])\s*[,>]', s))
    names = set(re.findall(r'(?<![\w.])([A-Z][a-z]\w*)\b', s)) | set(re.findall(r'(?<![\w.])([A-Z]\w*[a-z]\w*)\b', s))
    for n in sorted(names):
        if n in JAVA_LANG or n in local or n in tparams or n in explicit: continue
        if n in mine and (mine[n].rsplit('.', 1)[0] in wild or mine[n].rsplit('.', 1)[0] == pkg): continue
        if n in mine: print(f'{os.path.basename(f)}: classe MIA {n} senza import ({mine[n]})'); bad += 1; continue
        pk = KNOWN.get(n) or (list(glob_map[n])[0] if n in glob_map and len(glob_map[n]) == 1 else None)
        if pk is None: print(f'{os.path.basename(f)}: {n}: package sconosciuto (verificare a mano)'); continue
        if pk not in wild and not pk.startswith('net.minecraft.world.level.Level'): print(f'{os.path.basename(f)}: IMPORT MANCANTE? {n} -> {pk}'); bad += 1
print('problemi probabili:', bad)
