package com.claudemaster.horror;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import java.util.Optional;
import java.util.function.Predicate;

public final class Rays {
    /** Prima entità lungo lo sguardo di src entro range (null se nessuna o se un blocco si frappone). */
    public static LivingEntity target(LivingEntity src, double range, Predicate<Entity> filter) {
        Vec3 from = src.getEyePosition(), dir = src.getLookAngle(), to = from.add(dir.scale(range));
        BlockHitResult bh = src.level().clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, src));
        double lim = bh.getType() == HitResult.Type.MISS ? range * range : bh.getLocation().distanceToSqr(from);
        LivingEntity best = null; double bd = lim;
        for (Entity e : src.level().getEntities(src, src.getBoundingBox().expandTowards(dir.scale(range)).inflate(1.0), x -> x instanceof LivingEntity && x.isAlive() && filter.test(x))) {
            Optional<Vec3> hit = e.getBoundingBox().inflate(0.3).clip(from, to);
            if (hit.isPresent()) { double d = hit.get().distanceToSqr(from); if (d < bd) { bd = d; best = (LivingEntity) e; } }
        }
        return best;
    }
    public static boolean blocked(ServerLevel l, Vec3 a, Vec3 b, Entity who) { return l.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, who)).getType() != HitResult.Type.MISS; }
    public static void beam(ServerLevel l, Vec3 a, Vec3 b, int rgb) {
        Vec3 d = b.subtract(a); int n = (int) Math.max(1, d.length() / 0.7);
        for (int i = 0; i <= n; i++) Fx.dust(l, rgb, a.add(d.scale(i / (double) n)), 1, 0.03);
    }
    private Rays() {}
}
