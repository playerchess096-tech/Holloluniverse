package com.claudemaster.horror;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import java.util.*;
import java.util.function.Predicate;

/** Modifiche temporanee ai blocchi: l'originale viene sempre ripristinato (alla scadenza, a fine scontro o allo spegnimento del server). */
public final class TempBlocks {
    private record Entry(BlockState original, BlockState placed, long expire) {}
    private static final Map<ResourceKey<Level>, Map<BlockPos, Entry>> MAP = new HashMap<>();
    public static boolean set(ServerLevel l, BlockPos pos, BlockState st, int ticks) { return set(l, pos, st, ticks, false); }
    /** force=true permette di sostituire anche blocchi non aria (torce, erba...), mai blocchi con dati (BlockEntity). */
    public static boolean set(ServerLevel l, BlockPos pos, BlockState st, int ticks, boolean force) {
        Map<BlockPos, Entry> m = MAP.computeIfAbsent(l.dimension(), k -> new HashMap<>()); BlockPos key = pos.immutable(); Entry old = m.get(key);
        BlockState cur = l.getBlockState(pos);
        if (old == null) {
            if (l.getBlockEntity(pos) != null) return false;
            if (!(cur.isAir() || cur.canBeReplaced() || force)) return false;
            if (cur.getDestroySpeed(l, pos) < 0) return false;
        }
        BlockState orig = old != null ? old.original() : cur;
        l.setBlock(pos, st, 3); m.put(key, new Entry(orig, st, l.getGameTime() + ticks)); return true;
    }
    public static void tick(MinecraftServer s) {
        for (ServerLevel l : s.getAllLevels()) {
            Map<BlockPos, Entry> m = MAP.get(l.dimension()); if (m == null || m.isEmpty() || l.getGameTime() % 10 != 0) continue;
            for (Iterator<Map.Entry<BlockPos, Entry>> it = m.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<BlockPos, Entry> e = it.next();
                if (l.getGameTime() >= e.getValue().expire()) { restore(l, e.getKey(), e.getValue()); it.remove(); }
            }
        }
    }
    private static void restore(ServerLevel l, BlockPos p, Entry e) { if (l.isLoaded(p) && l.getBlockState(p) == e.placed()) l.setBlock(p, e.original(), 3); }
    public static void restoreAll(MinecraftServer s) {
        for (ServerLevel l : s.getAllLevels()) { Map<BlockPos, Entry> m = MAP.get(l.dimension()); if (m == null) continue; for (Map.Entry<BlockPos, Entry> e : m.entrySet()) restore(l, e.getKey(), e.getValue()); m.clear(); }
    }
    public static void restoreNear(ServerLevel l, BlockPos c, int r, Predicate<BlockState> filter) {
        Map<BlockPos, Entry> m = MAP.get(l.dimension()); if (m == null) return;
        for (Iterator<Map.Entry<BlockPos, Entry>> it = m.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<BlockPos, Entry> e = it.next();
            if (e.getKey().distSqr(c) <= (double) r * r && filter.test(e.getValue().placed())) { restore(l, e.getKey(), e.getValue()); it.remove(); }
        }
    }
    public static int count(ServerLevel l) { Map<BlockPos, Entry> m = MAP.get(l.dimension()); return m == null ? 0 : m.size(); }
    private TempBlocks() {}
}
