package com.claudemaster.horror.world;

import com.claudemaster.horror.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.phys.Vec3;

/** Dimensioni: Dimensione Verde (Entity 404, con il Cuore della Piaga) e Vuoto Pallido. Il ritorno è sempre possibile. */
public final class Realm {
    public static final ResourceKey<Level> R404 = ResourceKey.create(Registries.DIMENSION, HorrorMod.id("entity_404"));
    public static final ResourceKey<Level> HOLLOW = ResourceKey.create(Registries.DIMENSION, HorrorMod.id("pale_hollow"));
    public static void enter(ServerPlayer p) { go(p, R404); }
    public static void enterHollow(ServerPlayer p) { go(p, HOLLOW); }
    private static void go(ServerPlayer p, ResourceKey<Level> key) {
        MinecraftServer s = p.getServer(); if (s == null) return;
        if (!Config.DIMENSIONS.get()) { Fx.msg(p, "msg.realm_off"); return; }
        ServerLevel dst = s.getLevel(key); if (dst == null) { Fx.msg(p, "msg.realm_off"); return; }
        if (p.level().dimension() == key) { exit(p); return; }
        Saga sg = Saga.get(s);
        if (p.level().dimension() == Level.OVERWORLD) sg.sl(p.getUUID(), "retPos", p.blockPosition().asLong());
        if (key == R404) {
            if (sg.wi("realm_built") == 0) { dst.getStructureManager().get(HorrorMod.id("heart_sanctum")).ifPresent(t -> { BlockPos at = new BlockPos(14, 64, 14); t.placeInWorld(dst, at, at, new StructurePlaceSettings(), dst.random, 2); }); sg.wsi("realm_built", 1); }
            p.teleportTo(dst, 0.5, 64, 0.5, 0f, 0f);
        } else { int y = Fx.surfaceY(dst, 0, 0); p.teleportTo(dst, 0.5, y + 1, 0.5, 0f, 0f); }
        Fx.sound(dst, p.position(), "portal", 0.8f, 1f);
    }
    public static void exit(ServerPlayer p) {
        MinecraftServer s = p.getServer(); if (s == null) return; ServerLevel ow = s.overworld(); Saga sg = Saga.get(s); long r = sg.gl(p.getUUID(), "retPos");
        BlockPos bp = r == 0 ? ow.getSharedSpawnPos() : BlockPos.of(r); Vec3 st = Fx.standPos(ow, bp.getX() + 0.5, bp.getY(), bp.getZ() + 0.5);
        p.teleportTo(ow, st != null ? st.x : bp.getX() + 0.5, st != null ? st.y : bp.getY() + 1, st != null ? st.z : bp.getZ() + 0.5, p.getYRot(), 0f);
    }
    /** Salto del livello 7: dentro la Dimensione Verde per qualche secondo, poi ritorno in alto nel mondo (con breve caduta lenta: configurabile via effetto). */
    public static void hop(ServerPlayer p) {
        MinecraftServer s = p.getServer(); if (s == null || p.level().dimension() != Level.OVERWORLD) return; enter(p);
        s.tell(new TickTask(s.getTickCount() + 200, () -> { if (!p.isAlive()) return; exit(p); p.teleportTo(p.serverLevel(), p.getX(), p.getY() + 60, p.getZ(), p.getYRot(), 0f); p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 160, 0)); }));
    }
    public static void heartBroken(ServerPlayer p) {
        Saga sg = Saga.get(p.serverLevel()); sg.wsi("heart_destroyed", 1); sg.wsl("heart_recover_at", p.serverLevel().getGameTime() + 24000L);
        Fx.msg(p, "msg.heart"); Fx.sound(p.serverLevel(), p.position(), "tentacle", 1f, 0.5f);
        p.getServer().tell(new TickTask(p.getServer().getTickCount() + 60, () -> { if (p.isAlive() && p.level().dimension() == R404) exit(p); }));
    }
    private Realm() {}
}
