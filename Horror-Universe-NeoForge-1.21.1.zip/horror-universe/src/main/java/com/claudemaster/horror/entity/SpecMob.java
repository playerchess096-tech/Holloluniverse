package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.ai.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import java.util.ArrayList;
import java.util.List;

/** Mostro generico guidato dal manifest: modello, statistiche, abilità e debolezze arrivano da horror_content.json. */
public class SpecMob extends HorrorMob {
    private Content.MobSpec spec; private List<Ability> abs;
    public SpecMob(EntityType<? extends Monster> t, Level l) { super(t, l); }
    public Content.MobSpec spec() { if (spec == null) spec = Content.MOBS.get(BuiltInRegistries.ENTITY_TYPE.getKey(getType()).getPath()); return spec; }
    @Override public String key() { return spec().id(); }
    @Override public Ent family() { return Ent.ofOwner(spec().owner()); }
    @Override public boolean has(String a) { return spec().has(a); }
    @Override public List<String> weak() { return spec().weak(); }
    @Override protected List<Ability> abilities() {
        if (abs == null) { abs = new ArrayList<>(); for (String a : spec().abil()) { Ability x = Skills.create(a); if (x != null) abs.add(x); } }
        return abs;
    }
    @Override public boolean removeWhenFarAway(double d) { return !(has("guardian") && spec().weight() == 0) && super.removeWhenFarAway(d); }
    @Override protected void tickExtra() {
        if (!(level() instanceof ServerLevel l)) return;
        ServerPlayer p = tickCount % 2 == 0 ? Senses.nearestPlayer(l, this, 32) : null;
        if (has("freeze") && p != null) setNoAi(Senses.lookedAt(this, p));                       // Statua: immobile se guardata
        if ((has("ambush") || has("emerge")) && !mem.triggered) {                                   // Mimico/Bestia: fermo e nascosto finché non ci si avvicina
            if (tickCount == 1 && has("emerge")) setInvisible(true);
            if (!isNoAi() && tickCount > 2) setNoAi(true);
            if (p != null && distanceTo(p) < 4.5) { mem.triggered = true; setNoAi(false); setInvisible(false); Fx.particles(l, ParticleTypes.POOF, position().add(0, 0.5, 0), 25, 0.5); Fx.sound(l, position(), "mimic", 0.9f, 1f); }
        }
    }
    @Override public boolean doHurtTarget(Entity t) {
        if (has("statue_touch") && t instanceof Player p && p.getArmorValue() == 0) { boolean ok = p.hurt(damageSources().mobAttack(this), 16f); if (ok) Fx.sound(level(), position(), "statue_grind", 0.8f, 0.8f); return ok; }
        return super.doHurtTarget(t);
    }
}
