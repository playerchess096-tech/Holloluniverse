package com.claudemaster.horror.ai;

import com.claudemaster.horror.*;
import com.claudemaster.horror.entity.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/** Cervello a stati: decide l'umore in base a percezione, relazione con il giocatore, tratti (abilità) e salute. */
public class Brain {
    public Mood mood = Mood.OBSERVING;
    public Vec3 heard; public long heardAt;
    private final HorrorMob m;
    public Brain(HorrorMob m) { this.m = m; }
    public boolean wantsTarget(net.minecraft.world.entity.player.Player p) {
        if (p.isSpectator() || (p.isCreative() && !(m instanceof Entity404))) return false;
        if (m instanceof BossMob b) return b.fighting && p.getUUID().equals(b.fightPlayer);
        return mood == Mood.HOSTILE;
    }
    public void tick(ServerLevel l) {
        if (m instanceof BossMob b && b.fighting) { if (mood != Mood.DEFEATED && mood != Mood.FINAL && mood != Mood.VULNERABLE) mood = Mood.HOSTILE; return; }
        ServerPlayer p = Senses.nearestPlayer(l, m, 64);
        if (p == null) { mood = Mood.OBSERVING; return; }
        if (m instanceof BossMob b) { mood = b.presenceMood(m.distanceTo(p)); return; }
        boolean sees = Senses.canSee(m, p), hears = Senses.hears(m, p);
        if (hears && !sees) { heard = p.position(); heardAt = l.getGameTime(); }
        double d = m.distanceTo(p); float hp = m.getHealth() / m.getMaxHealth();
        Ent fam = m.family(); int rel = fam == null ? 0 : Saga.get(l).rel(p.getUUID(), fam);
        if (m.has("follow") || m.has("ally")) { mood = Mood.ALLY; if (m.owner == null) m.owner = p.getUUID(); return; }
        boolean hurtRecently = m.tickCount - m.mem.lastHurtTick < 100 && m.mem.hurtCount > 0;
        if (Config.ALLIANCES.get() && fam != null && rel >= 40 && !(hurtRecently && m.mem.lastAttacker != null && m.mem.lastAttacker.equals(p.getUUID()))) { mood = rel >= 70 ? Mood.ALLY : Mood.TRUCE; return; }
        if (hp < 0.25f && m.has("flee_low")) { if (mood != Mood.FLEEING) m.mem.fled++; mood = Mood.FLEEING; return; }
        if (m.has("night") && l.isDay() && l.canSeeSky(m.blockPosition())) { mood = Mood.FLEEING; return; }
        if (hurtRecently) { mood = (m.has("vanish") || m.has("gaze")) && !m.has("dash") ? Mood.FLEEING : Mood.HOSTILE; return; }
        if (m.has("guardian")) {
            Vec3 h = m.home == null ? m.position() : m.home;
            mood = p.position().distanceTo(h) < 12 && sees ? Mood.HOSTILE : (m.position().distanceTo(h) > 14 ? Mood.INVESTIGATING : Mood.OBSERVING);
            if (mood == Mood.INVESTIGATING) { heard = h; heardAt = l.getGameTime(); } return;
        }
        if (m.has("ambush") || m.has("emerge")) { mood = d < 4.5 ? Mood.HOSTILE : Mood.OBSERVING; return; }
        if (m.has("stalk")) {
            if (sees || hears) mood = d < 5 && !Senses.lookedAt(m, p) ? Mood.HOSTILE : Mood.STALKING; else mood = mood == Mood.HOSTILE && d < 10 ? Mood.HOSTILE : Mood.OBSERVING;
            return;
        }
        String owner = m.family() == null ? "" : m.family().id;
        boolean neutral = m instanceof SpecMob s && s.spec().owner().equals("neutral");
        if (neutral || m.has("vanish") && !m.has("dash")) { mood = Mood.OBSERVING; return; }
        if (sees) mood = Mood.HOSTILE;
        else if (hears && l.getGameTime() - heardAt < 200) mood = Mood.INVESTIGATING;
        else if (mood == Mood.HOSTILE && d < 24) mood = Mood.HOSTILE; else mood = Mood.OBSERVING;
    }
}
