package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.ai.Mood;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/** Il Custode dagli Occhi Bianchi: 1 Guardiano, 2 Prova del Contatto, 3 Scettro Elettrico, 4 Custode Supremo (scelta finale), 5 Rituale Proibito (Perle dell'End). */
public class Custode extends BossMob {
    private int waves, contacts, lastContact = -999, moved, pearlHits, pearlEnd, lastPearl = -999, pearls, finalPhase, choiceWait, phase;
    private boolean finalSpawned;
    public Custode(EntityType<? extends Custode> t, Level l) { super(t, l, Ent.CUSTODE); }
    @Override public String key() { return "custode"; }
    @Override protected boolean noMelee() { return bossLevel == 2 || bossLevel == 5 || choiceWait > 0; }
    @Override protected Weapons.Rule rule() {
        return switch (bossLevel) { case 1 -> Weapons.Rule.hits(1, 1); case 3 -> Weapons.Rule.hits(2, 1); case 4 -> Weapons.Rule.hitsThr(Config.CUSTODE4_THRESHOLD.get(), 3, 1); default -> Weapons.Rule.immune(); };
    }
    @Override protected float progress() { return bossLevel == 2 ? contacts / 3f : bossLevel == 5 ? pearlHits / 10f : super.progress(); }
    @Override protected void begin(ServerLevel l, ServerPlayer p) {
        waves = contacts = moved = pearlHits = finalPhase = choiceWait = phase = pearls = pearlEnd = 0; finalSpawned = false; clearGear();
        setHp(new double[]{0, 120, 60, 350, 600, 600}[Math.min(bossLevel, 5)]);
        if (bossLevel == 1) { equip(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET)); equip(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE)); equip(EquipmentSlot.LEGS, new ItemStack(Items.LEATHER_LEGGINGS)); equip(EquipmentSlot.FEET, new ItemStack(Items.LEATHER_BOOTS)); equip(EquipmentSlot.MAINHAND, new ItemStack(Items.WOODEN_SWORD)); }
        if (bossLevel == 3 || bossLevel == 4) equip(EquipmentSlot.MAINHAND, new ItemStack(Reg.item("electric_scepter")));
        if (bossLevel == 5) equip(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
        barStyle(new BossEvent.BossBarColor[]{null, BossEvent.BossBarColor.WHITE, BossEvent.BossBarColor.PINK, BossEvent.BossBarColor.YELLOW, BossEvent.BossBarColor.RED, BossEvent.BossBarColor.PURPLE}[Math.min(bossLevel, 5)],
                bossLevel == 2 ? BossEvent.BossBarOverlay.NOTCHED_6 : bossLevel == 5 ? BossEvent.BossBarOverlay.NOTCHED_10 : BossEvent.BossBarOverlay.PROGRESS);
        say(p, bossLevel == 5 ? 8 : bossLevel == 2 ? 3 : 1);
    }
    @Override public InteractionResult mobInteract(Player pl, InteractionHand h) {
        if (!level().isClientSide && fighting && bossLevel == 2 && h == InteractionHand.MAIN_HAND && pl instanceof ServerPlayer sp && sp.getUUID().equals(fightPlayer) && sp.getMainHandItem().isEmpty()) { contact(sp); return InteractionResult.SUCCESS; }
        return super.mobInteract(pl, h);
    }
    private void contact(ServerPlayer p) {   // un contatto continuo conta una sola volta: serve che il Custode si sia spostato e che siano passati 30 tick
        if (tickCount - lastContact < 30 || moved <= 0) return;
        ServerLevel l = (ServerLevel) level(); lastContact = tickCount; moved = 0; contacts++; Fx.msg(p, "msg.contact", contacts); Fx.sound(l, position(), "chime", 0.9f, 1f); Fx.particles(l, ParticleTypes.END_ROD, position().add(0, 1, 0), 25, 0.5);
        if (contacts >= 3) endFight(l, p, true); else { tpNear(l, p, 6, 11); moved++; }
    }
    @Override protected void script(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) { case 1 -> l1(l, p); case 2 -> l2(l, p); case 3, 4 -> l34(l, p); default -> l5(l, p); }
    }
    private void l1(ServerLevel l, ServerPlayer p) {
        float f = getHealth() / getMaxHealth();
        if (waves == 0 || (waves == 1 && f < 0.66f) || (waves == 2 && f < 0.33f)) { waves++; Fx.spawnNear(l, EntityType.ZOMBIE, p.position(), 9, p, 3, tag()); Fx.sound(l, position(), "growl", 0.8f, 0.9f); }
        if (every(160)) tpNear(l, p, 5, 9);
    }
    private void l2(ServerLevel l, ServerPlayer p) {
        if (every(90)) { tpNear(l, p, 6, 11); moved++; }
        if (at(300, 100) && Fx.countTag(l, position(), 64, tag()) < 1) summon(l, "white_eyed_zombie", 1, 9, p);
        if (every(220)) for (int i = 0; i < 3; i++) { Vec3 s = Fx.spotAround(l, p.position(), 1, 3); if (s != null) TempBlocks.set(l, BlockPos.containing(s), Blocks.COBWEB.defaultBlockState(), 120); }
        if (fightTicks > 6000) endFight(l, p, false);
    }
    private void l34(ServerLevel l, ServerPlayer p) {
        boolean sup = bossLevel == 4; float f = getHealth() / getMaxHealth();
        if (choiceWait > 0) { if (--choiceWait == 0) choose(p, true); return; }
        int iv = sup ? (f < 0.4f ? 60 : 90) : 110;
        if (every(iv)) { Vec3 at = p.position(); Fx.particles(l, ParticleTypes.ELECTRIC_SPARK, at.add(0, 0.2, 0), 25, 1.0); later(20, () -> Fx.lightning(l, at, 7f, 2.2, "electrified")); }
        if (at(300, 150)) { Vec3 c = p.position(); for (int k = 0; k < 5; k++) later(k * 20, () -> { for (int i = 0; i < 14; i++) Fx.dust(l, 0x80d0ff, c.add(Math.cos(i * 0.45) * 2.5, 0.2, Math.sin(i * 0.45) * 2.5), 1, 0.05); Fx.hitPlayers(l, c, 2.6, 0f, "electrified"); }); }
        if (at(sup ? 420 : 480, 60)) summon(l, new String[]{"pale_guardian", "lightning_knight", "end_sentinel"}[l.random.nextInt(3)], 1, 10, p);
        if (sup && at(500, 250)) {
            List<EntityType<?>> pool = BuiltInRegistries.ENTITY_TYPE.getTag(TagKey.create(Registries.ENTITY_TYPE, HorrorMod.id("custode_summons"))).map(t -> t.stream().map(h -> (EntityType<?>) h.value()).toList()).orElse(List.of(EntityType.ZOMBIE));
            if (!pool.isEmpty()) summonType(l, pool.get(l.random.nextInt(pool.size())), 2, 9, p, Config.MAX_MINIONS.get());
        }
        if (f < 0.5f && phase == 0) { phase = 1; Fx.sound(l, position(), "thunder_far", 1f, 0.8f); Fx.lightning(l, position(), 0f, 1, null); say(p, 4); }
        if (every(200)) tpNear(l, p, 5, 10);
    }
    @Override protected void onLethal(ServerLevel l, ServerPlayer p, DamageSource s) {
        if (bossLevel == 4 && p != null) {
            if (choiceWait > 0) return;
            choiceWait = 6000; setHealth(1f); setNoAi(true); brain.mood = Mood.DEFEATED; say(p, 5); Fx.msg(p, "msg.choice");
            p.sendSystemMessage(Component.translatable("horror_universe.msg.choice_spare").withStyle(st -> st.withColor(ChatFormatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/horror choice spare")))
                    .append(Component.literal("   ")).append(Component.translatable("horror_universe.msg.choice_kill").withStyle(st -> st.withColor(ChatFormatting.RED).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/horror choice kill")))));
        } else super.onLethal(l, p, s);
    }
    @Override protected boolean preHurt(DamageSource src, float a) { if (choiceWait > 0) { if (src.getEntity() instanceof ServerPlayer sp) choose(sp, false); return true; } return false; }
    public void choose(ServerPlayer p, boolean spare) {
        if (choiceWait <= 0 || !(level() instanceof ServerLevel l)) return; choiceWait = 0; Saga s = Saga.get(l); s.wsi("custode_fate", spare ? 1 : 2);   // la scelta resta salvata nel mondo
        if (spare) { Fx.msg(p, "msg.fate_spare"); say(p, 7); s.addRel(p.getUUID(), ent, 30); Fx.give(p, "white_symbol", 2); Fx.give(p, "ritual_ash", 2); }
        else { Fx.msg(p, "msg.fate_kill"); s.addRel(p.getUUID(), ent, -40); Fx.give(p, "electric_scepter", 1); }
        setNoAi(false); endFight(l, p, true);
    }
    public static boolean chooseNear(ServerPlayer p, boolean spare) {
        for (Custode c : p.serverLevel().getEntitiesOfClass(Custode.class, p.getBoundingBox().inflate(64), x -> x.choiceWait > 0)) { c.choose(p, spare); return true; } return false;
    }
    private void l5(ServerLevel l, ServerPlayer p) {
        if (finalPhase == 0) {
            if (tickCount > pearlEnd && every(70)) tpNear(l, p, 6, 14);
            if (at(260, 20) && pearls < 16) { Fx.give(p, "ritual_pearl", 2); pearls += 2; Fx.sound(l, p.position(), "chime", 0.7f, 1.4f); }
            if (at(260, 60)) { pearlEnd = tickCount + 120; addEffect(new MobEffectInstance(MobEffects.GLOWING, 120, 0)); Fx.particles(l, ParticleTypes.END_ROD, position().add(0, 1, 0), 30, 0.6); }
            if (at(400, 200)) summonType(l, EntityType.ENDERMAN, 2, 10, p, Config.MAX_MINIONS.get());
            if (at(500, 100)) { p.setDeltaMovement(0, 1.1, 0); p.hurtMarked = true; }
            if (at(700, 300)) tempEyes(p);
            if (at(330, 140)) { Vec3 at = p.position(); Fx.dust(l, 0xe040ff, at, 30, 1.2); later(20, () -> Fx.lightning(l, at, 6f, 2.2, "electrified")); }
            if (at(600, 450)) summon(l, "custode_shadow", 2, 8, p);
            if (every(240)) p.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
        } else {
            if (!finalSpawned) { finalSpawned = true; summon(l, "ritual_enderman", 1, 10, p); say(p, 6); }
            else if (fightTicks > 40 && Fx.countTag(l, position(), 100, tag()) == 0 && countTagged(l, "") == 0) endFight(l, p, true);
            if (every(120)) summonType(l, EntityType.ENDERMAN, 1, 9, p, Config.MAX_MINIONS.get());
        }
        if (fightTicks > 12000) endFight(l, p, false);
    }
    /** Chiamato dal gestore dei proiettili: colpo valido solo con Perla Rituale, nella finestra di ancoraggio, senza doppi conteggi. */
    public boolean onPearlHit(ServerPlayer p) {
        if (!fighting || bossLevel != 5 || finalPhase != 0 || !p.getUUID().equals(fightPlayer) || tickCount > pearlEnd || tickCount - lastPearl < 20) return false;
        ServerLevel l = (ServerLevel) level(); lastPearl = tickCount; pearlEnd = 0; pearlHits++; Fx.msg(p, "msg.pearl_hit", pearlHits);
        Fx.particles(l, ParticleTypes.REVERSE_PORTAL, position().add(0, 1, 0), 40, 0.6); Fx.sound(l, position(), "teleport", 1f, 0.6f);
        removeEffect(MobEffects.GLOWING); if (pearlHits >= 10) { finalPhase = 1; say(p, 5); } else tpNear(l, p, 10, 18);
        return true;
    }
    private void tempEyes(ServerPlayer p) {   // oggetti temporanei SOLO negli slot vuoti: nulla viene tolto o distrutto
        if (!Config.TEMP_INVENTORY.get()) return; int n = 0;
        for (int i = 0; i < 36 && n < 3; i++) if (p.getInventory().getItem(i).isEmpty()) { ItemStack s = new ItemStack(Items.ENDER_EYE); Marks.set(s, "hu_temp", true); p.getInventory().setItem(i, s); n++; }
        later(400, () -> clearTemp(p));
    }
    public static void clearTemp(ServerPlayer p) { for (int i = 0; i < p.getInventory().getContainerSize(); i++) if (Marks.has(p.getInventory().getItem(i), "hu_temp")) p.getInventory().setItem(i, ItemStack.EMPTY); }
    @Override protected void cleanup(ServerLevel l, ServerPlayer p) { if (p != null) clearTemp(p); killMinions(l); setNoAi(false); TempBlocks.restoreNear(l, blockPosition(), 40, s -> s.is(Blocks.COBWEB)); }
    @Override protected void reward(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) {
            case 1 -> Fx.give(p, "white_symbol", 1);
            case 2 -> { Fx.give(p, "pale_dust", 3); Fx.give(p, "scroll_custode", 1); }
            case 3 -> Fx.give(p, "electric_scepter", 1);
            case 5 -> { Fx.give(p, "void_essence", 1); Fx.give(p, "ritual_pearl", 2); }
            default -> { }
        }
    }
}
