package com.claudemaster.horror;

import com.claudemaster.horror.api.HorrorApi;
import com.claudemaster.horror.entity.BossMob;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.ItemAttributeModifiers;

/** Sistema delle armi e delle vulnerabilità (Parte 9 del prompt). Il valore usato è l'attacco mostrato nel tooltip (1 + modificatori). */
public final class Weapons {
    public static final TagKey<Item> VALID = TagKey.create(Registries.ITEM, HorrorMod.id("valid_weapons"));
    public static final TagKey<Item> INVALID = TagKey.create(Registries.ITEM, HorrorMod.id("invalid_weapons"));
    public record Rule(boolean blocked, double threshold, int h3, int h6, boolean specialOnly) {
        public static Rule immune() { return new Rule(true, 0, 0, 0, false); }
        public static Rule normal() { return new Rule(false, 0, 0, 0, false); }
        public static Rule thr(double t) { return new Rule(false, t, 0, 0, false); }
        public static Rule hits(int h3, int h6) { return new Rule(false, 0, h3, h6, false); }
        public static Rule hitsThr(double t, int h3, int h6) { return new Rule(false, t, h3, h6, false); }
        public static Rule special(int h3, int h6) { return new Rule(false, 0, h3, h6, true); }
    }
    /** Attacco "da tooltip": 1 + somma dei modificatori additivi di ATTACK_DAMAGE nella mano principale. Funziona con armi di altre mod. */
    public static double attack(ItemStack s) {
        if (s.isEmpty()) return 1.0;
        Double ov = HorrorApi.attackOverride(s.getItem()); if (ov != null) return ov;
        double v = 1.0;
        for (ItemAttributeModifiers.Entry e : s.getAttributeModifiers().modifiers())
            if (e.slot().test(EquipmentSlot.MAINHAND) && e.attribute().value() == Attributes.ATTACK_DAMAGE.value() && e.modifier().operation() == AttributeModifier.Operation.ADD_VALUE) v += e.modifier().amount();
        return v;
    }
    public static ItemStack held(DamageSource s) {
        if (s.getDirectEntity() instanceof LivingEntity le) return le.getMainHandItem();
        if (!(s.getDirectEntity() instanceof Projectile) && s.getEntity() instanceof LivingEntity o) return o.getMainHandItem();
        return ItemStack.EMPTY;
    }
    public static boolean isPlague(ItemStack s) { return s.is(Reg.item("plague_blade")) || s.is(Reg.item("lord_blade")); }
    public static boolean isWeapon3(ItemStack s) { return s.is(Reg.item("plague_blade")); }
    public static boolean isWeapon6(ItemStack s) { return s.is(Reg.item("lord_blade")); }
    /** Restituisce il danno effettivo (0 = colpo rifiutato). Le armi di livello 3/6 infliggono una frazione fissa della salute massima. */
    public static float resolve(BossMob boss, DamageSource src, float amt, Rule r) {
        if (r.blocked()) return 0f;
        ItemStack w = held(src);
        if (w.is(INVALID)) return 0f;
        float max = boss.getMaxHealth();
        if (isWeapon6(w) && r.h6() > 0) return max / r.h6() + 0.5f;
        if (isWeapon3(w) && r.h3() > 0) return max / r.h3() + 0.5f;
        if (r.specialOnly()) return 0f;
        if (r.threshold() > 0) {
            double a = src.is(DamageTypeTags.IS_PROJECTILE) ? amt : (w.is(VALID) ? Math.max(attack(w), r.threshold() + 0.01) : attack(w));
            if (a <= r.threshold()) return 0f;
        }
        return amt;
    }
    private Weapons() {}
}
