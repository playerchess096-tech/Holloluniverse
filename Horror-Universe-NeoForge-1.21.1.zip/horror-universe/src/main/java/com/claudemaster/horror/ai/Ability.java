package com.claudemaster.horror.ai;

import com.claudemaster.horror.entity.HorrorMob;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

public interface Ability {
    void tick(HorrorMob m, ServerLevel l);
    default void hit(HorrorMob m, LivingEntity target) {}
    default float hurt(HorrorMob m, DamageSource src, float amount) { return amount; }
    default void death(HorrorMob m, ServerLevel l) {}
}
