package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.ai.*;
import com.claudemaster.horror.api.HorrorApi;
import com.claudemaster.horror.world.Director;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import java.util.UUID;

/** Struttura comune delle sei entità principali: presenza autonoma + boss fight a livelli con regole di vulnerabilità. */
public abstract class BossMob extends HorrorMob {
    public final Ent ent;
    public int bossLevel = 1;
    public boolean fighting;
    public UUID fightPlayer;
    protected int fightTicks, lastValid = -100, lastMsg = -100, presenceTicks, lookTicks;
    public int validHits;
    protected boolean ending;
    protected final ServerBossEvent bar = new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);

    protected BossMob(EntityType<? extends BossMob> t, Level l, Ent e) { super(t, l); ent = e; }
    @Override public Ent family() { return ent; }
    public String tag() { return "hu_of_" + getUUID(); }
    protected abstract Weapons.Rule rule();
    protected abstract void begin(ServerLevel l, ServerPlayer p);
    protected abstract void script(ServerLevel l, ServerPlayer p);
    protected abstract void reward(ServerLevel l, ServerPlayer p);
    protected void cleanup(ServerLevel l, ServerPlayer p) {}
    protected float progress() { return Mth.clamp(getHealth() / getMaxHealth(), 0f, 1f); }
    protected boolean truelyKillable() { return false; }
    protected boolean preHurt(DamageSource s, float a) { return false; }
    protected boolean customHit(ServerPlayer p, DamageSource s, float dmg) { return false; }
    protected void idleExtra(ServerLevel l, ServerPlayer p) {}
    protected int lookLimit() { return 60; }
    protected boolean fightsOnPresence() { return true; }
    public Mood presenceMood(double d) { return d < 12 ? Mood.FLEEING : Mood.OBSERVING; }
    protected void onLethal(ServerLevel l, ServerPlayer p, DamageSource s) { endFight(l, p, true); }

    protected void setHp(double base) { getAttribute(Attributes.MAX_HEALTH).setBaseValue(base * Config.DIFFICULTY.get()); setHealth(getMaxHealth()); }
    protected void equip(EquipmentSlot s, ItemStack st) { setItemSlot(s, st); setDropChance(s, 0f); }
    protected void clearGear() { for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND}) equip(s, ItemStack.EMPTY); }
    protected boolean every(int n) { return fightTicks % n == 0; }
    protected boolean at(int n, int off) { return fightTicks % n == off; }
    public int nextLevel(ServerPlayer p) { return Saga.get(p.serverLevel()).level(p.getUUID(), ent) + 1; }

    public void startFight(ServerPlayer p, int lvl) {
        if (!(level() instanceof ServerLevel l)) return;
        bossLevel = Mth.clamp(lvl, 1, 9); fighting = true; fightPlayer = p.getUUID(); fightTicks = 0; validHits = 0; ending = false; presenceTicks = 0; diffDone = true; owner = p.getUUID();
        setNoAi(false); brain.mood = Mood.HOSTILE; setTarget(p); mem.phase = 0;
        begin(l, p);
        bar.setName(Component.translatable("entity.horror_universe." + key()).append(Component.literal("  [" + bossLevel + "]")));
        bar.addPlayer(p); HorrorApi.fireLevel(key(), bossLevel, p, true, false); Fx.sound(l, position(), "stinger", 0.6f, 0.8f);
    }
    public void endFight(ServerLevel l, ServerPlayer p, boolean win) {
        if (!fighting) return; fighting = false; ending = false; bar.removeAllPlayers(); returnStolen(); cleanup(l, p);
        if (win && p != null) {
            Saga s = Saga.get(l); if (bossLevel <= ent.max && s.level(p.getUUID(), ent) < bossLevel) s.si(p.getUUID(), "lvl." + ent.id, bossLevel);
            Fx.msg(p, "msg.victory"); reward(l, p); Director.afterFight(l, p);
        } else if (p != null) Fx.msg(p, "msg.defeat");
        HorrorApi.fireLevel(key(), bossLevel, p, false, win);
        Fx.particles(l, ParticleTypes.PORTAL, position().add(0, 1, 0), 40, 0.6); Fx.sound(l, position(), "teleport", 0.8f, 0.7f); discard();
    }
    protected ServerPlayer fightPlayer(ServerLevel l) { return fightPlayer == null ? null : l.getServer().getPlayerList().getPlayer(fightPlayer); }
    @Override protected void tickExtra() {
        if (!(level() instanceof ServerLevel l)) return;
        ServerPlayer p = fightPlayer(l);
        if (fighting) {
            fightTicks++;
            if (p == null || !p.isAlive() || p.level() != level() || p.isSpectator()) { endFight(l, null, false); return; }
            setTarget(p); script(l, p); bar.setProgress(progress());
        } else {
            ServerPlayer near = Senses.nearestPlayer(l, this, 80);
            if (near != null) idle(l, near); else if (++presenceTicks > 2400) discard();
        }
    }
    protected void idle(ServerLevel l, ServerPlayer p) {
        presenceTicks++; double d = distanceTo(p);
        if (Senses.lookedAt(this, p) && d > 4) lookTicks++; else lookTicks = Math.max(0, lookTicks - 1);
        if (lookTicks > lookLimit()) { vanish(l); return; }
        if (d < 10 && presenceTicks > 100 && tickCount % 20 == 0) { if (wantsFight(l, p)) startFight(p, nextLevel(p)); else if (l.random.nextInt(4) == 0) vanish(l); }
        if (presenceTicks > 3600) vanish(l);
        idleExtra(l, p);
    }
    protected boolean wantsFight(ServerLevel l, ServerPlayer p) {
        int next = nextLevel(p); if (!fightsOnPresence() || next > ent.max || !Director.unlocked(l, ent, next)) return false;
        return l.random.nextDouble() < 0.35 * Config.FIGHT_FREQ.get();
    }
    public void vanish(ServerLevel l) { Fx.particles(l, ParticleTypes.LARGE_SMOKE, position().add(0, 1, 0), 25, 0.5); Fx.sound(l, position(), "whoosh", 0.7f, 0.6f); discard(); }

    @Override public boolean hurt(DamageSource src, float amt) {
        if (level().isClientSide) return false;
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(src, amt);
        ServerPlayer att = src.getEntity() instanceof ServerPlayer sp ? sp : null; ServerLevel l = (ServerLevel) level();
        if (!fighting) { if (att != null && tickCount - lastMsg > 40) { lastMsg = tickCount; Fx.bar(att, "msg.immune"); } return false; }
        if (preHurt(src, amt)) return false;
        Weapons.Rule r = rule(); float dmg = Weapons.resolve(this, src, amt, r);
        if (dmg <= 0f) { if (att != null && tickCount - lastMsg > 40) { lastMsg = tickCount; Fx.bar(att, r.blocked() ? "msg.immune" : "msg.no_weapon"); Fx.particles(l, ParticleTypes.SMOKE, position().add(0, 1, 0), 8, 0.3); } return false; }
        if (tickCount - lastValid < 11) return false;
        HorrorApi.HitEvent ev = HorrorApi.fireHit(this, src, dmg); if (ev.isCanceled()) return false; dmg = ev.getDamage();
        lastValid = tickCount; validHits++;
        if (att != null && customHit(att, src, dmg)) return false;
        if (getHealth() - dmg <= 1f && !truelyKillable()) { onLethal(l, att != null ? att : fightPlayer(l), src); return false; }
        invulnerableTime = 0; return super.hurt(src, dmg);
    }
    @Override public void die(DamageSource s) { if (fighting && level() instanceof ServerLevel l) { fighting = false; bar.removeAllPlayers(); cleanup(l, fightPlayer(l)); } super.die(s); }
    @Override public void remove(Entity.RemovalReason r) { bar.removeAllPlayers(); super.remove(r); }
    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); if (fighting) bar.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bar.removePlayer(p); }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); t.putInt("lvl", bossLevel); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); bossLevel = Math.max(1, t.getInt("lvl")); }

    // --- strumenti per gli script ---
    protected void tpNear(ServerLevel l, ServerPlayer p, double min, double max) {
        Vec3 s = Fx.spotAround(l, p.position(), min, max); if (s == null) return;
        Fx.particles(l, ParticleTypes.PORTAL, position().add(0, 1, 0), 20, 0.4); Fx.sound(l, position(), "teleport", 0.6f, 1f);
        moveTo(s.x, s.y, s.z); getNavigation().stop(); Fx.particles(l, ParticleTypes.PORTAL, s.add(0, 1, 0), 20, 0.4);
    }
    protected int summon(ServerLevel l, String id, int n, double r, ServerPlayer p) { return summonType(l, Reg.type(id), n, r, p, Config.MAX_MINIONS.get()); }
    protected int summonType(ServerLevel l, EntityType<?> t, int n, double r, ServerPlayer p, int cap) {
        int can = Math.min(n, cap - Fx.countTag(l, position(), 90, tag())); if (can <= 0) return 0;
        return Fx.spawnNear(l, t, p.position(), r, p, can, tag());
    }
    protected void orb(ServerLevel l, ServerPlayer p, float dmg, int rgb, String fx) { Orbs.fire(l, this, getEyePosition(), p.getEyePosition(), 0.85f, dmg, rgb, fx); Fx.sound(l, position(), "cast", 0.6f, 1f); }
    protected void darkBlocks(ServerLevel l, ServerPlayer p, int n, String block, int ticks) {
        for (int i = 0; i < n; i++) { Vec3 s = Fx.spotAround(l, p.position(), 1.5, 6); if (s != null) TempBlocks.set(l, net.minecraft.core.BlockPos.containing(s), Reg.block(block).defaultBlockState(), ticks); }
    }
    protected void say(ServerPlayer p, int n) { Fx.say(p, ent, n); }
    protected void barStyle(BossEvent.BossBarColor c, BossEvent.BossBarOverlay o) { bar.setColor(c); bar.setOverlay(o); }
    protected int countTagged(ServerLevel l, String suffix) { return Fx.countTag(l, position(), 100, tag() + suffix); }
    /** Rimuove tutte le evocazioni di questo boss. */
    protected void killMinions(ServerLevel l) { for (Mob m : l.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(120), e -> e.getTags().stream().anyMatch(t -> t.startsWith(tag())))) m.discard(); }
}
