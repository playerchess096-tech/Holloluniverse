package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** L'Uomo Magico: 1 Apprendista, 2 Mago delle Illusioni, 3 Signore degli Incantesimi (tre rune), 4 Arcimago (energia magica), 5 Dio della Magia (cinque rune + bastone). */
public class Mago extends BossMob {
    private final List<BlockPos> runes = new ArrayList<>();
    private BlockPos staff; private int mana = 100;
    public Mago(EntityType<? extends Mago> t, Level l) { super(t, l, Ent.MAGO); }
    @Override public String key() { return "mago"; }
    private boolean casting() { int c = fightTicks % 160; return c >= 100 && c < 130; }
    @Override protected Weapons.Rule rule() {
        return switch (bossLevel) {
            case 1 -> Weapons.Rule.normal();
            case 2 -> casting() ? Weapons.Rule.normal() : Weapons.Rule.immune();
            case 3 -> runes.isEmpty() ? Weapons.Rule.normal() : Weapons.Rule.immune();
            case 4 -> mana <= 0 ? Weapons.Rule.thr(Config.MAGE4_THRESHOLD.get()) : Weapons.Rule.immune();
            default -> Weapons.Rule.immune();
        };
    }
    @Override protected float progress() { return bossLevel == 3 ? runes.size() / 3f : bossLevel == 4 ? mana / 100f : bossLevel == 5 ? (staff != null ? 0.05f : runes.size() / 5f) : super.progress(); }
    @Override protected void begin(ServerLevel l, ServerPlayer p) {
        runes.clear(); staff = null; mana = 100; clearGear(); equip(EquipmentSlot.MAINHAND, new ItemStack(Reg.item("rune_staff")));
        setHp(new double[]{0, 150, 180, 260, 420, 600}[Math.min(bossLevel, 5)]); barStyle(BossEvent.BossBarColor.PURPLE, bossLevel == 5 ? BossEvent.BossBarOverlay.NOTCHED_6 : BossEvent.BossBarOverlay.PROGRESS);
        say(p, bossLevel == 3 ? 5 : bossLevel == 2 ? 3 : 1);
        if (bossLevel == 3) placeRunes(l, p, 3); if (bossLevel == 5) placeRunes(l, p, 5);
        if (bossLevel == 4) for (int i = 0; i < 3; i++) Fx.spawnNear(l, Reg.type("arcane_guardian"), p.position(), 12, p, 1, tag() + "_g");
    }
    private void placeRunes(ServerLevel l, ServerPlayer p, int n) {
        for (int i = 0; i < n && runes.size() < n; i++) { Vec3 s = Fx.spotAround(l, p.position(), 10, 26); if (s == null) continue; BlockPos bp = BlockPos.containing(s); if (TempBlocks.set(l, bp, Reg.block("rune_node").defaultBlockState(), 24000, true)) runes.add(bp); }
        Fx.msg(p, "msg.rune_found", runes.size());
    }
    @Override protected void script(ServerLevel l, ServerPlayer p) {
        runes.removeIf(bp -> !l.getBlockState(bp).is(Reg.block("rune_node")));
        if (bossLevel >= 3) for (BlockPos bp : runes) { if (every(10)) Fx.particles(l, ParticleTypes.END_ROD, Vec3.atCenterOf(bp).add(0, 1.5, 0), 2, 0.1); if (every(40) && p.distanceToSqr(Vec3.atCenterOf(bp)) < 225) Fx.soundTo(p, "rune_hum", 0.5f, 1f, Vec3.atCenterOf(bp)); }
        switch (bossLevel) { case 1 -> l1(l, p); case 2 -> l2(l, p); case 3 -> l3(l, p); case 4 -> l4(l, p); default -> l5(l, p); }
    }
    private void l1(ServerLevel l, ServerPlayer p) {
        if (every(60)) orb(l, p, 5f, 0xd070ff, null);
        if (at(200, 0)) for (BlockPos bp : BlockPos.betweenClosed(p.blockPosition().offset(-8, -2, -8), p.blockPosition().offset(8, 4, 8))) if (l.getBlockState(bp).is(Blocks.TORCH) || l.getBlockState(bp).is(Blocks.WALL_TORCH)) TempBlocks.set(l, bp, Blocks.AIR.defaultBlockState(), 200, true);
        if (at(240, 100)) Fx.soundTo(p, "steps_behind", 0.5f, 1f, p.position().subtract(p.getLookAngle().scale(4)));
        if (every(100)) tpNear(l, p, 4, 8);
        if (getHealth() / getMaxHealth() < 0.3f) { say(p, 6); endFight(l, p, true); }   // l'apprendista fugge quando è in svantaggio
    }
    private void l2(ServerLevel l, ServerPlayer p) {
        if (every(120)) summon(l, "illusion_double", 1, 8, p);
        if (at(200, 0)) { Vec3 d = p.getLookAngle(); for (int i = 2; i <= 4; i++) TempBlocks.set(l, BlockPos.containing(p.getX() + d.x * i, p.getY(), p.getZ() + d.z * i), Reg.block("illusion_block").defaultBlockState(), 300); }
        if (fightTicks % 160 == 100) { Fx.sound(l, position(), "cast", 1f, 0.8f); Fx.particles(l, ParticleTypes.ENCHANT, position().add(0, 1, 0), 50, 0.7); }
        if (fightTicks % 160 == 110) orb(l, p, 6f, 0xd070ff, "rune_seal");
        if (every(80) && !casting()) tpNear(l, p, 5, 10);
        if (fightTicks > 8000) endFight(l, p, false);
    }
    private void l3(ServerLevel l, ServerPlayer p) {
        if (at(300, 100)) curse(p); if (every(70)) orb(l, p, 6f, 0xd070ff, null); if (at(500, 250)) summon(l, "runic_golem", 1, 12, p);
        if (every(160)) tpNear(l, p, 6, 12); if (fightTicks > 9000) endFight(l, p, false);
    }
    private void curse(ServerPlayer p) {
        switch (random.nextInt(4)) { case 0 -> p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 1)); case 1 -> p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 0)); case 2 -> p.addEffect(new MobEffectInstance(MobEffects.JUMP, 120, 128)); default -> Fx.fx(p, "rune_seal", 160, 0); }
    }
    private void l4(ServerLevel l, ServerPlayer p) {
        int gens = Fx.countTag(l, position(), 90, tag() + "_g"); int old = mana; mana = Math.round(100f * gens / 3f);
        if (mana <= 0 && old > 0) Fx.msg(p, "msg.mage_energy");
        if (gens < 3 && at(900, 0) && mana > 0) Fx.spawnNear(l, Reg.type("arcane_guardian"), p.position(), 12, p, 1, tag() + "_g");   // le barriere si rigenerano se si ignorano i generatori
        if (at(400, 150)) Fx.fx(p, "gravity_flux", 120, 0); if (at(500, 100)) summon(l, "mage_copy", 2, 9, p);
        if (every(200)) darkBlocks(l, p, 3, "pale_bricks", 300); if (every(70) && mana > 0) orb(l, p, 7f, 0xd070ff, null); if (every(150)) tpNear(l, p, 5, 11);
        if (fightTicks > 12000) endFight(l, p, false);
    }
    @Override protected boolean preHurt(DamageSource s, float a) {   // assorbimento e restituzione degli incantesimi/proiettili finché ha energia
        if (bossLevel == 4 && mana > 0 && s.is(DamageTypeTags.IS_PROJECTILE) && s.getEntity() instanceof ServerPlayer p && level() instanceof ServerLevel l) { orb(l, p, 5f, 0xd070ff, null); return true; }
        return false;
    }
    private void l5(ServerLevel l, ServerPlayer p) {
        if (every(400) && !runes.isEmpty()) { for (BlockPos bp : new ArrayList<>(runes)) TempBlocks.restoreNear(l, bp, 1, s -> s.is(Reg.block("rune_node"))); int left = runes.size(); runes.clear(); placeRunes(l, p, left); }   // le rune cambiano posizione
        if (runes.isEmpty() && staff == null) { Vec3 s = Fx.spotAround(l, p.position(), 3, 6); if (s != null) { staff = BlockPos.containing(s); TempBlocks.set(l, staff, Reg.block("staff_core").defaultBlockState(), 6000, true); summon(l, "staff_keeper", 1, 10, p); say(p, 2); } }
        if (staff != null && !l.getBlockState(staff).is(Reg.block("staff_core"))) { endFight(l, p, true); return; }   // bastone distrutto: vittoria
        if (every(50)) orb(l, p, 7f, 0xd070ff, null); if (at(250, 100)) curse(p); if (at(400, 200)) Fx.fx(p, "gravity_flux", 100, 0);
        if (at(500, 300)) summon(l, "mage_copy", 2, 9, p); if (every(160)) tpNear(l, p, 6, 13); if (fightTicks > 14000) endFight(l, p, false);
    }
    /** Chiamato quando il giocatore spezza un Nodo Runico o il Nucleo del Bastone. */
    public static void blockBroken(ServerLevel l, ServerPlayer p, BlockPos pos) {
        for (Mago m : l.getEntitiesOfClass(Mago.class, p.getBoundingBox().inflate(90), x -> x.fighting)) if (m.runes.remove(pos)) { Fx.msg(p, "msg.rune_found", m.runes.size()); Fx.sound(l, Vec3.atCenterOf(pos), "chime", 1f, 0.7f); }
    }
    public static void pact(ServerPlayer p) { Saga s = Saga.get(p.serverLevel()); s.addRel(p.getUUID(), Ent.MAGO, 30); Fx.say(p, Ent.MAGO, 4); Fx.give(p, "arcane_dust", 2); }
    @Override protected void cleanup(ServerLevel l, ServerPlayer p) {
        killMinions(l); for (Mob m : l.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(120), e -> e.getTags().contains(tag() + "_g"))) m.discard();
        for (BlockPos bp : runes) TempBlocks.restoreNear(l, bp, 1, s -> true); if (staff != null) TempBlocks.restoreNear(l, staff, 1, s -> true);
        TempBlocks.restoreNear(l, blockPosition(), 60, s -> s.is(Reg.block("illusion_block")) || s.is(Reg.block("pale_bricks")) || s.is(Blocks.AIR));
    }
    @Override protected void reward(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) {
            case 1 -> Fx.give(p, "arcane_dust", 3); case 2 -> Fx.give(p, "rune_shard", 2); case 3 -> { Fx.give(p, "ancient_rune_1", 1); Fx.give(p, "scroll_mago", 1); }
            case 4 -> { Fx.give(p, "ancient_rune_2", 1); Fx.give(p, "rune_staff", 1); }
            default -> { for (int i = 3; i <= 5; i++) Fx.give(p, "ancient_rune_" + i, 1); Fx.give(p, "mage_pact", 1); }
        }
    }
}
