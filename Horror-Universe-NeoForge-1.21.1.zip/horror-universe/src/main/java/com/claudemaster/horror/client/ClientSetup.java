package com.claudemaster.horror.client;

import com.claudemaster.horror.*;
import com.claudemaster.horror.entity.HorrorMob;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Rendering: riusa i modelli vanilla (umanoide, scheletro, creeper, ragno, enderman) con texture HD e occhi luminosi; scuotimento visuale con l'effetto Tremore. */
public final class ClientSetup {
    static ResourceLocation tex(String id, String suffix) { return HorrorMod.id("textures/entity/" + id + suffix + ".png"); }
    static final class Glow<T extends net.minecraft.world.entity.Mob, M extends EntityModel<T>> extends EyesLayer<T, M> {
        private final RenderType rt;
        Glow(RenderLayerParent<T, M> p, ResourceLocation t) { super(p); rt = RenderType.eyes(t); }
        @Override public RenderType renderType() { return rt; }
    }
    static final class HumanoidR extends HumanoidMobRenderer<HorrorMob, HumanoidModel<HorrorMob>> {
        private final ResourceLocation t; private final float s;
        HumanoidR(EntityRendererProvider.Context c, ModelLayerLocation layer, String id, boolean glow, float scale) {
            super(c, new HumanoidModel<>(c.bakeLayer(layer)), 0.5f * scale); t = tex(id, ""); s = scale;
            addLayer(new HumanoidArmorLayer<>(this, new HumanoidModel<>(c.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel<>(c.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), c.getModelManager()));
            if (glow) addLayer(new Glow<>(this, tex(id, "_glow")));
        }
        @Override public ResourceLocation getTextureLocation(HorrorMob m) { return t; }
        @Override protected void scale(HorrorMob m, PoseStack ps, float pt) { ps.scale(s, s, s); }
    }
    static final class GenericR<M extends EntityModel<HorrorMob>> extends MobRenderer<HorrorMob, M> {
        private final ResourceLocation t; private final float s;
        GenericR(EntityRendererProvider.Context c, M model, String id, boolean glow, float scale) { super(c, model, 0.5f * scale); t = tex(id, ""); s = scale; if (glow) addLayer(new Glow<>(this, tex(id, "_glow"))); }
        @Override public ResourceLocation getTextureLocation(HorrorMob m) { return t; }
        @Override protected void scale(HorrorMob m, PoseStack ps, float pt) { ps.scale(s, s, s); }
    }
    static EntityRenderer<HorrorMob> make(EntityRendererProvider.Context c, String model, String id, boolean glow, float sc) {
        return switch (model) {
            case "skeleton" -> new HumanoidR(c, ModelLayers.SKELETON, id, glow, sc);
            case "creeper" -> new GenericR<>(c, new CreeperModel<HorrorMob>(c.bakeLayer(ModelLayers.CREEPER)), id, glow, sc);
            case "spider" -> new GenericR<>(c, new SpiderModel<HorrorMob>(c.bakeLayer(ModelLayers.SPIDER)), id, glow, sc);
            case "enderman" -> new GenericR<>(c, new EndermanModel<HorrorMob>(c.bakeLayer(ModelLayers.ENDERMAN)), id, glow, sc);
            default -> new HumanoidR(c, ModelLayers.PLAYER, id, glow, sc);
        };
    }
    @EventBusSubscriber(modid = HorrorMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class Mod {
        @SuppressWarnings({"unchecked", "rawtypes"})
        @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            for (Content.MobSpec m : Content.MOBS.values()) e.registerEntityRenderer((EntityType) Reg.type(m.id()), (EntityRendererProvider) c -> make(c, m.model(), m.id(), m.glow(), m.scale()));
            for (Content.BossSpec b : Content.BOSSES.values()) e.registerEntityRenderer((EntityType) Reg.type(b.id()), (EntityRendererProvider) c -> make(c, b.model(), b.id(), true, b.scale()));
        }
    }
    @EventBusSubscriber(modid = HorrorMod.MODID, value = Dist.CLIENT)
    public static final class Game {
        @SubscribeEvent public static void shake(ViewportEvent.ComputeCameraAngles e) {
            LocalPlayer p = Minecraft.getInstance().player; if (p == null || !p.hasEffect(Reg.fx("tremor")) || !Config.SHAKE.get()) return;
            float t = p.tickCount + (float) e.getPartialTick(); e.setPitch(e.getPitch() + Mth.sin(t * 1.7f) * 0.9f); e.setRoll(e.getRoll() + Mth.cos(t * 2.3f) * 0.9f);
        }
    }
    private ClientSetup() {}
}
