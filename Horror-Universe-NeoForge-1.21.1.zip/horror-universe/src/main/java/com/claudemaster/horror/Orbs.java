package com.claudemaster.horror;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Sfere magiche/oscure: proiettili "leggeri" senza nuovi tipi di entità (movimento, particelle, danno ai giocatori). */
public final class Orbs {
    private static final class O { ServerLevel l; Vec3 p, v; float dmg; int rgb, life; String fx; UUID owner; }
    private static final List<O> LIST = new ArrayList<>();
    public static void fire(ServerLevel l, Entity owner, Vec3 from, Vec3 to, float speed, float dmg, int rgb, String fx) {
        O o = new O(); o.l = l; o.p = from; o.v = to.subtract(from).normalize().scale(speed); o.dmg = dmg; o.rgb = rgb; o.fx = fx; o.life = 80; o.owner = owner == null ? null : owner.getUUID(); LIST.add(o);
    }
    public static void tick(MinecraftServer s) {
        if (LIST.isEmpty()) return;
        for (Iterator<O> it = LIST.iterator(); it.hasNext(); ) {
            O o = it.next(); o.p = o.p.add(o.v); o.life--; Fx.dust(o.l, o.rgb, o.p, 2, 0.08); boolean hit = false;
            for (ServerPlayer pl : o.l.getEntitiesOfClass(ServerPlayer.class, new AABB(o.p, o.p).inflate(0.8))) {
                if (pl.isCreative() || pl.isSpectator()) continue;
                Entity ow = o.owner == null ? null : o.l.getEntity(o.owner);
                pl.hurt(ow == null ? o.l.damageSources().magic() : o.l.damageSources().indirectMagic(ow, ow), o.dmg); if (o.fx != null) Fx.fx(pl, o.fx, 100, 0); hit = true;
            }
            BlockPos bp = BlockPos.containing(o.p);
            if (hit || o.life <= 0 || !o.l.getBlockState(bp).getCollisionShape(o.l, bp).isEmpty()) it.remove();
        }
    }
    public static void clear() { LIST.clear(); }
    private Orbs() {}
}
