package com.claudemaster.horror;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import java.util.List;

/** Marcature reversibili sugli oggetti (corrotto / neutralizzato / temporaneo) tramite componente CUSTOM_DATA. */
public final class Marks {
    public static boolean has(ItemStack s, String k) { if (s.isEmpty()) return false; CustomData cd = s.get(DataComponents.CUSTOM_DATA); return cd != null && cd.copyTag().getBoolean(k); }
    public static void set(ItemStack s, String k, boolean v) { CustomData.update(DataComponents.CUSTOM_DATA, s, t -> { if (v) t.putBoolean(k, true); else t.remove(k); }); }
    public static void lore(ItemStack s, String key) { s.set(DataComponents.LORE, new ItemLore(List.of(Component.translatable(key).withStyle(ChatFormatting.DARK_PURPLE)))); }
    public static void clearLore(ItemStack s) { s.remove(DataComponents.LORE); }
    public static boolean unusable(ItemStack s) { return has(s, "hu_corrupted") || has(s, "hu_neutralized"); }
    private Marks() {}
}
