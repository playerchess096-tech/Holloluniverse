package com.claudemaster.horror;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Tutte le opzioni richieste dalla Parte 16 del prompt. Le opzioni pericolose si possono disattivare. */
public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();
    public static final ModConfigSpec.IntValue PROFILE = B.comment("Profilo horror: 0 = leggero, 1 = standard, 2 = intenso (cambia frequenza e atmosfera, NON la potenza dei boss)").defineInRange("horrorProfile", 1, 0, 2);
    public static final ModConfigSpec.BooleanValue AUTONOMOUS = B.comment("Le entità compaiono da sole nel mondo (presenza autonoma)").define("autonomousEntities", true);
    public static final ModConfigSpec.IntValue EVENT_SECONDS = B.comment("Secondi medi tra un evento horror e il successivo").defineInRange("eventIntervalSeconds", 50, 10, 3600);
    public static final ModConfigSpec.IntValue APPEAR_COOLDOWN = B.comment("Secondi minimi tra due apparizioni della stessa entità").defineInRange("appearanceCooldownSeconds", 420, 30, 7200);
    public static final ModConfigSpec.DoubleValue FIGHT_FREQ = B.comment("Moltiplicatore della frequenza delle boss fight (0 = mai spontanee)").defineInRange("bossFightFrequency", 1.0, 0.0, 5.0);
    public static final ModConfigSpec.BooleanValue JUMPSCARES = B.comment("Jumpscare (suoni improvvisi e titoli)").define("jumpscares", true);
    public static final ModConfigSpec.BooleanValue SHAKE = B.comment("Scuotimento della visuale (effetto Tremore)").define("screenShake", true);
    public static final ModConfigSpec.BooleanValue FAKE_MESSAGES = B.comment("Falsi messaggi di ingresso in chat (solo narrativi)").define("fakeJoinMessages", true);
    public static final ModConfigSpec.IntValue MAX_MINIONS = B.comment("Numero massimo di evocazioni vive per ogni entità").defineInRange("maxMinions", 10, 1, 60);
    public static final ModConfigSpec.IntValue MAX_CLONES = B.comment("Numero massimo di cloni contemporanei").defineInRange("maxClones", 4, 1, 20);
    public static final ModConfigSpec.DoubleValue DIFFICULTY = B.comment("Moltiplicatore di salute e danni di tutte le creature della mod").defineInRange("difficultyMultiplier", 1.0, 0.1, 10.0);
    public static final ModConfigSpec.DoubleValue ATTACK_THRESHOLD = B.comment("Soglia di attacco generale (arma con attacco > soglia può ferire le entità a soglia)").defineInRange("attackThreshold", 7.0, 0.0, 100.0);
    public static final ModConfigSpec.DoubleValue CUSTODE4_THRESHOLD = B.comment("Soglia del Custode livello 4 (8 = spada di netherite)").defineInRange("custode4Threshold", 7.0, 0.0, 100.0);
    public static final ModConfigSpec.DoubleValue MAGE4_THRESHOLD = B.comment("Soglia dell'Arcimago (6.5 = spada di diamante, attacco 7)").defineInRange("archmageThreshold", 6.5, 0.0, 100.0);
    public static final ModConfigSpec.IntValue E404_TIMER = B.comment("Secondi del timer apocalittico di Entity 404 livello 7").defineInRange("entity404ApocalypseSeconds", 600, 60, 7200);
    public static final ModConfigSpec.BooleanValue ALLIANCES = B.comment("Alleanze e tregue persistenti con le entità").define("allowAlliances", true);
    public static final ModConfigSpec.BooleanValue DIMENSIONS = B.comment("Abilita le dimensioni (Dimensione Verde e Vuoto Pallido)").define("enableDimensions", true);
    public static final ModConfigSpec.BooleanValue WORLD_DESTRUCTION = B.comment("Distruzione NARRATIVA del mondo se scade il timer (mai cancella salvataggi: solo ambiente devastato)").define("narrativeWorldDestruction", true);
    public static final ModConfigSpec.BooleanValue PERMADEATH = B.comment("Morte permanente NARRATIVA (spettatore finché non c'è il rito di recupero; nessun dato cancellato)").define("narrativePermadeath", true);
    public static final ModConfigSpec.IntValue PERMADEATH_MIN = B.comment("Minuti dopo i quali un'anima persa torna da sola").defineInRange("permadeathAutoRecoverMinutes", 15, 1, 600);
    public static final ModConfigSpec.BooleanValue HOUSE_EXPLOSION = B.comment("L'esplosione narrativa della casa danneggia davvero i blocchi (default: solo effetto visivo)").define("houseExplosionDamagesBlocks", false);
    public static final ModConfigSpec.BooleanValue STEAL = B.comment("Le entità possono sottrarre temporaneamente oggetti (sempre restituiti)").define("allowItemTheft", true);
    public static final ModConfigSpec.BooleanValue ASSIMILATION = B.comment("Entity 404 può assimilare boss di altre mod (tag horror_universe:assimilable)").define("bossAssimilation", true);
    public static final ModConfigSpec.BooleanValue TEMP_INVENTORY = B.comment("Il Custode livello 5 può aggiungere oggetti temporanei all'inventario (reversibile)").define("temporaryInventoryItems", true);
    public static final ModConfigSpec.BooleanValue COMPAT_AI = B.comment("L'AI considera anche creature, armi e oggetti di altre mod (tag e attributi)").define("modCompatAi", true);
    public static final ModConfigSpec SPEC = B.build();
    private Config() {}
    public static double mul() { return PROFILE.get() == 0 ? 0.5 : PROFILE.get() == 2 ? 1.8 : 1.0; }
}
