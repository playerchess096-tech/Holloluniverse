package com.claudemaster.horror.ai;

/** Stati dell'AI (Parte 12.2): non tutte le entità usano tutti gli stati. */
public enum Mood { DORMANT, OBSERVING, STALKING, INVESTIGATING, HOSTILE, FLEEING, PREPARING, VULNERABLE, DEFEATED, TRUCE, ALLY, FINAL }
