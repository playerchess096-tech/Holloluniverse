package com.claudemaster.horror;

import net.minecraft.ChatFormatting;

/** Le sei entità principali. */
public enum Ent {
    CUSTODE("custode", 5, ChatFormatting.WHITE), CORROTTO("corrotto", 5, ChatFormatting.DARK_PURPLE), E404("entity404", 7, ChatFormatting.GREEN),
    MAGO("mago", 5, ChatFormatting.LIGHT_PURPLE), STEVE("steve", 5, ChatFormatting.AQUA), OSSERVATORE("osservatore", 3, ChatFormatting.GRAY);
    public final String id; public final int max; public final ChatFormatting color;
    Ent(String id, int max, ChatFormatting c) { this.id = id; this.max = max; this.color = c; }
    public static Ent of(String id) { for (Ent e : values()) if (e.id.equals(id) || e.name().equalsIgnoreCase(id)) return e; return null; }
    public static Ent ofOwner(String owner) { return switch (owner) { case "custode" -> CUSTODE; case "corrotto" -> CORROTTO; case "e404" -> E404; case "mago" -> MAGO; case "steve" -> STEVE; default -> null; }; }
}
